import React, { useState } from "react";
import { DndContext, useDraggable, useDroppable } from "@dnd-kit/core";

const initialPeople = [
  { id: "1", name: "Alice" },
  { id: "2", name: "Bruno" },
  { id: "3", name: "Carla" },
];

const areas = ["TI", "Financeiro", "Produção"];

function Person({ id, name }) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({ id });
  const style = {
    transform: transform ? `translate(${transform.x}px, ${transform.y}px)` : undefined,
  };
  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className="p-2 bg-white rounded shadow cursor-move"
    >
      👤 {name}
    </div>
  );
}

function Area({ id, people, isCentral }) {
  const { setNodeRef } = useDroppable({ id });
  return (
    <div
      ref={setNodeRef}
      className={\`p-4 border m-2 rounded w-1/4 min-h-[200px] \${isCentral ? "bg-gray-100" : "bg-blue-100"}\`}
    >
      <h2 className="font-bold mb-2">{isCentral ? "Não alocados" : id}</h2>
      <div className="flex flex-wrap gap-2">
        {people.map((p) => (
          <Person key={p.id} id={p.id} name={p.name} />
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [unassigned, setUnassigned] = useState(initialPeople);
  const [assignments, setAssignments] = useState({});

  const handleDragEnd = (event) => {
    const { over, active } = event;
    if (!over) return;

    const person = unassigned.find((p) => p.id === active.id) ||
                   Object.values(assignments).flat().find((p) => p.id === active.id);

    if (!person) return;

    if (over.id === "centro") {
      setUnassigned([...unassigned, person]);
      removeFromAssignments(person.id);
    } else {
      setAssignments((prev) => ({
        ...prev,
        [over.id]: [...(prev[over.id] || []), person],
      }));
      setUnassigned(unassigned.filter((p) => p.id !== person.id));
      removeFromAssignments(person.id, over.id);
    }
  };

  const removeFromAssignments = (id, excludeArea) => {
    setAssignments((prev) => {
      const newAssign = {};
      for (let [area, people] of Object.entries(prev)) {
        newAssign[area] = area !== excludeArea ? people.filter((p) => p.id !== id) : people;
      }
      return newAssign;
    });
  };

  return (
    <DndContext onDragEnd={handleDragEnd}>
      <div className="flex h-screen gap-2 p-4">
        {areas.map((area) => (
          <Area key={area} id={area} people={assignments[area] || []} />
        ))}
        <Area id="centro" people={unassigned} isCentral />
      </div>
    </DndContext>
  );
}
